﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777220
	objId: 16777220
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiButton
	{
		id: q486539322
		objId: 486539322
		x: 180
		y: 376
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/50#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiQmlRectangle
	{
		id: q671088650
		objId: 671088650
		x: 726
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088651
		objId: 671088651
		x: 724
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088652
		objId: 671088652
		x: 724
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088653
		objId: 671088653
		x: 724
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088654
		objId: 671088654
		x: 724
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088655
		objId: 671088655
		x: 724
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088656
		objId: 671088656
		x: 637
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088657
		objId: 671088657
		x: 635
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088658
		objId: 671088658
		x: 635
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088659
		objId: 671088659
		x: 635
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088660
		objId: 671088660
		x: 635
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088661
		objId: 671088661
		x: 635
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088662
		objId: 671088662
		x: 548
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088663
		objId: 671088663
		x: 546
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088664
		objId: 671088664
		x: 546
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088665
		objId: 671088665
		x: 546
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088666
		objId: 671088666
		x: 546
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088667
		objId: 671088667
		x: 546
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088668
		objId: 671088668
		x: 459
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088669
		objId: 671088669
		x: 457
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088670
		objId: 671088670
		x: 457
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088671
		objId: 671088671
		x: 457
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088672
		objId: 671088672
		x: 457
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088673
		objId: 671088673
		x: 457
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088674
		objId: 671088674
		x: 370
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088675
		objId: 671088675
		x: 368
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088676
		objId: 671088676
		x: 368
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088677
		objId: 671088677
		x: 368
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088678
		objId: 671088678
		x: 368
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088679
		objId: 671088679
		x: 368
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088680
		objId: 671088680
		x: 281
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088681
		objId: 671088681
		x: 279
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088682
		objId: 671088682
		x: 279
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088683
		objId: 671088683
		x: 279
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088684
		objId: 671088684
		x: 279
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088685
		objId: 671088685
		x: 279
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088686
		objId: 671088686
		x: 192
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088687
		objId: 671088687
		x: 190
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088688
		objId: 671088688
		x: 190
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088689
		objId: 671088689
		x: 190
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088690
		objId: 671088690
		x: 190
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088691
		objId: 671088691
		x: 190
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088692
		objId: 671088692
		x: 14
		y: 268
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088693
		objId: 671088693
		x: 12
		y: 226
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088694
		objId: 671088694
		x: 12
		y: 182
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088695
		objId: 671088695
		x: 12
		y: 134
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088696
		objId: 671088696
		x: 12
		y: 84
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088697
		objId: 671088697
		x: 12
		y: 43
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088698
		objId: 671088698
		x: 99
		y: 267
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088699
		objId: 671088699
		x: 97
		y: 225
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088700
		objId: 671088700
		x: 97
		y: 181
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088701
		objId: 671088701
		x: 97
		y: 133
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088702
		objId: 671088702
		x: 97
		y: 83
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
	IGuiQmlRectangle
	{
		id: q671088703
		objId: 671088703
		x: 97
		y: 42
		width: 48
		height: 27
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 48
		qm_RectangleHeight: 27
	}
}
